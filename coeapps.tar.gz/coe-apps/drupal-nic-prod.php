<?php

$wwwroot = "https://local.ceedar.org/nic";
#$host = 'ip-172-31-54-0';
$host = 'local.ceedar.org';


return array(
    'db' => array(
        'host' => '127.0.0.1',
        'port' => '3306',
        'dbname-default' => 'db_nic_ceedar_org_d7',
        'dbname-ceedar' => 'db_nic_whse_ceedar',
        'dbname-ceedar_main' => 'db_nic_ceedar_custom',
        'username' => 'root',
        'password' => 'mysql',
        'type' => 'mysql',
        'prefix' => '',
    ),
    'dboptions' => array(
        'dbpersist' => 0,
        'dbsocket' => 0,
    ),
    'hash-salt' => '9PUEwaTwxY7K8TqjukzXSk7eT2BpTWcKExa8XnNp8La',
    'host' => $host,
    'code' => '/Applications/AMPPS/www/ceedar/nic',
    'admin' => 'admin',
    'directorypermissions' => 0777, /* note: octal */

        // unused in Drupal. Not sure why this is here
    'passwordsaltmain' => ';K2nce*x:bWMqi+iSgmXu[G#CIFsj0',

    'dataroot' => '',
    'session' => '',
    'wwwroot' => $wwwroot,
    'contacts' => 'sclay',
    'desc' => 'CEEDAR NIC prod instance',
);
