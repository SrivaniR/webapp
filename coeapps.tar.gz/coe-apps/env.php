<?php return 'prod';
/**
 * DO NOT CHANGE THIS!
 * 
 * @see http://community.education.ufl.edu/community/pg/pages/view/97079/
 * This sets the environment string that apps will use to configure themselves.
 * E.g. if our app is 'foo-' and we return 'dev', Elgg will get its
 * configuration from /etc/coe-apps/foo-dev.php
 */
